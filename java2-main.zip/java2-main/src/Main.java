
interface Calculavel {
    double calcularImposto();
    double calcularJuros();
    double calcularLucro();
    double calcularDesconto();
    double calcularTaxaManuseio();
    double calcularPrecoFinal();
    double calcularTotal();
}

enum CategoriaProduto {
    ELETRONICO, ALIMENTO, PAPELARIA;
}




